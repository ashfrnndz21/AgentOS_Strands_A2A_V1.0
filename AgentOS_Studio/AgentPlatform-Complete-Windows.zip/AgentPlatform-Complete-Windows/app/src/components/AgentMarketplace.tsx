
import React from 'react';
import { ModernAgentMarketplace } from './AgentMarketplace/ModernAgentMarketplace';

export function AgentMarketplace() {
  return <ModernAgentMarketplace />;
}
